# G-STUDY — Nền tảng học tiếng Anh lớp 10

G-STUDY là ứng dụng web học tiếng Anh lớp 10, gồm đăng ký/đăng nhập, lộ trình 10 Unit, lưu kết quả học tập, thống kê hôm nay so với hôm qua, trang cá nhân, đổi mật khẩu, tùy chỉnh hình nền và gửi liên hệ quản trị viên.

## Triển khai lên Vercel

### 1. Đưa mã nguồn lên GitHub

Đưa toàn bộ file trong thư mục này vào **thư mục gốc** (root) của repository. Các file `app.py`, `index.html`, `requirements.txt` và `vercel.json` phải nằm ngay ở root, không nằm trong một thư mục con. Không upload bất kỳ file `.db`, `.sqlite` hoặc `.env` nào.

### 2. Import dự án lên Vercel

1. Vào https://vercel.com/new và Import repository GitHub.
2. Project Name: `g-study` (hoặc tên slug còn khả dụng).
3. Root Directory: `./`.
4. Framework Preset: `Other` là được nếu Vercel chưa tự nhận Flask.
5. Để Build Command và Output Directory trống/mặc định.
6. Nhấn Deploy để tạo project. Giao diện trang chủ có thể mở, nhưng API đăng nhập và dữ liệu sẽ báo chưa cấu hình cho tới khi hoàn thành bước PostgreSQL bên dưới.

### 3. Kết nối PostgreSQL trong Vercel

Vercel Functions không có ổ đĩa ghi bền vững phù hợp để lưu file SQLite. G-STUDY đã được chuyển sang PostgreSQL cho tài khoản, phiên đăng nhập, tiến độ, kết quả và tin nhắn liên hệ.

1. Mở project `g-study` trên Vercel.
2. Vào Storage hoặc Marketplace, chọn tích hợp PostgreSQL (ví dụ Neon hoặc Supabase) và tạo database.
3. Kết nối database với project `g-study`.
4. Kiểm tra Project Settings → Environment Variables đã có `DATABASE_URL`. Nếu nhà cung cấp tạo biến tên khác, hãy thêm `DATABASE_URL` với connection string PostgreSQL tương ứng. Ưu tiên connection string pooled/serverless nếu nhà cung cấp có cung cấp.

Không đưa connection string lên GitHub hoặc gửi trong chat.

### 4. Tạo tài khoản quản trị

Trong Project Settings → Environment Variables, thêm hai biến:

- `ADMIN_EMAIL`: email quản trị bạn muốn dùng.
- `ADMIN_PASSWORD`: mật khẩu mạnh do bạn tự đặt, tối thiểu 12 ký tự.

Áp dụng cho môi trường Production (và Preview nếu cần). Sau đó vào Deployments và Redeploy deployment mới nhất để biến môi trường được áp dụng.

Ứng dụng tạo tài khoản admin khi database khởi tạo nếu email chưa tồn tại. Nếu email đã tồn tại, tài khoản đó được nâng quyền admin nhưng mật khẩu đang có không bị ghi đè. Vì vậy, hãy chọn email riêng mà bạn kiểm soát và cấu hình các biến trước khi công khai website.

### 5. Kiểm tra website

Mở domain Vercel cấp và kiểm tra:

- `/health` phải trả về `ok: true` và `database_configured: true`.
- Trang chủ hiển thị G-STUDY.
- Đăng ký một tài khoản học sinh thử nghiệm, đăng xuất rồi đăng nhập lại.
- Kiểm tra lộ trình, thống kê và lưu kết quả học.
- Đăng nhập tài khoản admin để kiểm tra trang quản trị.

## Chạy thử trên máy tính

Yêu cầu Python 3.11 trở lên.

```bash
pip install -r requirements.txt
ADMIN_EMAIL=admin@example.com ADMIN_PASSWORD='Use-A-Strong-Password-12' python app.py
```

Mở `http://localhost:8090`. Khi chạy local mà không có `DATABASE_URL`, ứng dụng dùng SQLite ở `english10-local.db` để thử nghiệm. Trong môi trường Vercel, PostgreSQL là bắt buộc.

Trên Windows PowerShell:

```powershell
py -m pip install -r requirements.txt
$env:ADMIN_EMAIL='admin@example.com'
$env:ADMIN_PASSWORD='Use-A-Strong-Password-12'
py app.py
```

## Tính năng chính

- Giao diện responsive cho máy tính và điện thoại.
- Trên điện thoại có thanh điều hướng 4 mục: Trang chủ, Lộ trình, Thống kê và Cá nhân.
- Trang Cá nhân có đổi mật khẩu, đổi tài khoản/đăng xuất, tùy chỉnh hình nền, hướng dẫn và liên hệ quản trị viên.
- Chạm logo G-STUDY 5 lần liên tiếp để mở cổng quản trị; API chỉ cho tài khoản có quyền `admin` truy cập.
- Lưu tài khoản, phiên đăng nhập, tiến độ, kết quả và liên hệ trên PostgreSQL.

## Lưu ý bảo mật và tính năng chưa cấu hình

- Không commit `.env`, connection string hoặc database vào GitHub.
- Không dùng mật khẩu mẫu trong production.
- Tạo tài khoản admin bằng `ADMIN_EMAIL` và `ADMIN_PASSWORD` trong Vercel; nên đổi mật khẩu sau lần đăng nhập đầu tiên.
- Đăng nhập Google chưa được cấu hình OAuth.
- Gửi email tự động đặt lại mật khẩu chưa được cấu hình; API hiện chỉ trả thông báo chung.
- Hình nền tùy chỉnh được lưu trên trình duyệt/thiết bị đó, chưa đồng bộ giữa các thiết bị.
- Trước khi mở rộng cho nhiều người dùng, nên bổ sung giới hạn thử đăng nhập, CSRF protection phù hợp, sao lưu PostgreSQL và kiểm thử bảo mật độc lập.
